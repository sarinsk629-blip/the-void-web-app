import { MharmyrauxApp } from "@/components/mharmyraux-app"

export default function Home() {
  return <MharmyrauxApp />
}
